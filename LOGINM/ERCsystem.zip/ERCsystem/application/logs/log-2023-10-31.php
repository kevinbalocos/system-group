<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-10-31 12:49:19 --> Severity: error --> Exception: Call to undefined method Auth::passwordsMatch() D:\Chrome Download\XAMP INSTALLER\INSTALLATION FOLDER\htdocs\BALOCOS\ERCsystem\application\controllers\Auth.php 45
ERROR - 2023-10-31 12:50:08 --> Severity: error --> Exception: Call to undefined method Auth_model::isEmailRegistered() D:\Chrome Download\XAMP INSTALLER\INSTALLATION FOLDER\htdocs\BALOCOS\ERCsystem\application\controllers\Auth.php 53
ERROR - 2023-10-31 12:50:58 --> Login failed for email: 22@22
ERROR - 2023-10-31 12:50:58 --> Login failed after registration for email: 22@22
ERROR - 2023-10-31 12:51:10 --> Login failed for email: 222@22
ERROR - 2023-10-31 12:51:10 --> Login failed after registration for email: 222@22
ERROR - 2023-10-31 12:51:19 --> Login failed for email: 222@22
ERROR - 2023-10-31 12:51:19 --> Login failed for email: 222@22
ERROR - 2023-10-31 12:52:59 --> Severity: error --> Exception: Call to undefined method Auth_model::login() D:\Chrome Download\XAMP INSTALLER\INSTALLATION FOLDER\htdocs\BALOCOS\ERCsystem\application\controllers\Auth.php 25
ERROR - 2023-10-31 12:53:23 --> Login failed for email: 123@123123
ERROR - 2023-10-31 12:53:29 --> Login failed for email: 123@123
ERROR - 2023-10-31 12:56:05 --> Login failed for email: kevinbalocos@gmail.com
ERROR - 2023-10-31 12:56:05 --> Login failed after registration for email: kevinbalocos@gmail.com
ERROR - 2023-10-31 12:56:14 --> Login failed for email: kevinbalocos@gmail.com
ERROR - 2023-10-31 12:57:10 --> Login failed for email: kevinbalocos@gmail.com
