<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('auth_model');
        $this->load->library('session');
        $this->load->database(); // Load the database explicitly

    }

    public function index() {
        $this->load->view('forlogin/viewlogin');
    }

    public function viewregister() {
        $this->load->view('forlogin/viewregister');
    }

    public function viewlogin() {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        // Regular expression for basic email validation
        $email_pattern = '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';
    
        if (preg_match($email_pattern, $email)) {
            $user = $this->auth_model->setlogin($email, $password);
    
            if ($user) {
                $this->session->set_userdata('user_id', $user['id']);
                redirect('dashboard'); // Redirect only if email and password match
            } else {
                $this->load->view('forlogin/viewlogin', ['error' => 'Invalid email or password']);
            }
        } else {
            $this->load->view('forlogin/viewlogin', ['error' => 'Invalid email format']);
        }
    }
    
    public function register() {
        $data = array(
            'id' => null,
            'username' => $this->input->post('username'),
            'email' => $this->input->post('email'),
            'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT),
        );

        if ($this->auth_model->register($data)) {
            redirect(base_url('auth'));
        } else {
            $this->load->view('forlogin/viewregister', ['error' => 'Registration failed']);
        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth/viewlogin');
    }
}
