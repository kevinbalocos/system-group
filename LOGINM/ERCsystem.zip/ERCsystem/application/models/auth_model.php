<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Load the database library
    }
    
    public function setlogin($email, $password) {
        $query = $this->db->get_where('login', ['email' => $email]);
        $user = $query->row_array();
    
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        } else {
            // Log database error for debugging
            $db_error = $this->db->error();
            log_message('error', 'Database Error: ' . print_r($db_error, true));
            
            return false;
        }
    }
    
    public function register($data) {
    $data['password'] = $this->input->post('password'); // Save the plaintext password (COMMENT KO IF PRESENTATION)

        return $this->db->insert('register', $data);
    }
}

