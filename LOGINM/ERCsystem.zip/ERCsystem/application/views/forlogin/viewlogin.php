<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            background-color: transparent;
            font-family: Arial, sans-serif;
            background-image: url('your-background-image.jpg'); /* Add your background image URL here */
            background-size: cover;
            background-position: center;
            backdrop-filter: blur(5px); /* Add blur amount here */
        }

        h2 {
            text-align: center;
            color: #fff; /* Text color for the title */
        }

        .form-container {
            max-width: 80%;
            margin: 0 auto;
            display: flex;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add a subtle shadow */
        }

        .image-container {
            flex: 1;
            background: url('your-image-url.jpg') center/cover no-repeat; /* Add your image URL here */
        }

        .form-content {
            background-color: rgba(255, 255, 255, 0.7); /* Transparent white background */
            flex: 1;
            padding: 20px;
        }

        form input {
            width:90%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            
        }

        button {
            width: 90%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .signup-link {
            text-align: center;
        }

        .signup-link a {
            color: #007bff;
            text-decoration: none;
        }

        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Login</h2>
    <?php if (isset($error)) echo '<p>' . $error . '</p>'; ?>

    <div class="form-container">
        <div class="image-container"></div>
        <div class="form-content">
        <form method="post" action="<?php echo base_url('auth/viewlogin'); ?>">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>

            <p class="signup-link">Don't have an account? <a href="<?php echo base_url('auth/viewregister'); ?>">Register here</a></p>
        </div>
    </div>
</body>
</html>